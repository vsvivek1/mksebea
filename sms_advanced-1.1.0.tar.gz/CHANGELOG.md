## 1.1.0

* Upgraded gradle

## 1.0.2

* A fix on ios build by @eslamodeh
* 
## 1.0.1

* Added Web implementation

## 1.0.0

* Added IOS implementation

## 0.0.1

* TODO: Describe initial release.
