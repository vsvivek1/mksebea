package com.elyudde.sms_advanced.status

enum class SmsStatus {
    SMS_RECEIVED, SMS_SENT
}
